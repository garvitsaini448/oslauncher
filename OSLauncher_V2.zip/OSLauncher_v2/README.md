# OSLauncher V2

Kotlin + Jetpack Compose Android launcher based on the supplied V1 project.

## V2 features

- Windows/Start-style category tile folders for Files, Games, Social and Apps.
- Advanced top status widget:
  - green Wi-Fi icon when connected
  - red Wi-Fi-off icon when disconnected
  - battery, network speed and Bluetooth status
  - online weather, temperature, weather condition and approximate network location
- Samsung-Music-style home music widget:
  - album art when embedded in the audio file
  - title/artist
  - previous, play/pause and next
  - seek bar
- Bottom universal search:
  - installed apps
  - local music
  - local videos
  - MediaStore-indexed device files
  - Google web search and YouTube fallback buttons
- Swipe-up app drawer.
- Long press any app for App Info / Uninstall.
- Restore One UI Home moved into Launcher Settings.
- GitHub Actions workflow builds the debug APK with JDK 17 + Gradle 8.7.

## Build

Android Studio:
1. Open this `OSLauncher` directory.
2. Let Android Studio sync Gradle.
3. Build `app`.

GitHub:
- Push the repository.
- Open the Actions tab.
- The `Build OSLauncher V2` workflow produces `app-debug.apk` as an artifact.

## Permissions

Android 13+ asks for audio/video access so the music widget and local media search can work.
Android 12 and below uses READ_EXTERNAL_STORAGE.

Weather uses internet access and an IP-based approximate location service, then requests current weather from Open-Meteo. No API key is stored in the project.

## Important Android storage limitation

A normal launcher cannot silently index every arbitrary private/document file on modern Android. The V2 search therefore searches installed apps and MediaStore-indexed media/files. It does not bypass Android scoped-storage protections.

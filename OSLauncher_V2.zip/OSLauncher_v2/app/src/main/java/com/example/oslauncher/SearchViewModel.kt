package com.example.oslauncher

import android.app.Application
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.Locale

enum class SearchType { APP, MUSIC, VIDEO, FILE }

data class SearchResult(
    val title: String,
    val subtitle: String,
    val type: SearchType,
    val packageName: String? = null,
    val uri: android.net.Uri? = null
)

class SearchViewModel(application: Application) : AndroidViewModel(application) {
    private val context = application.applicationContext
    private val _results = MutableStateFlow<List<SearchResult>>(emptyList())
    val results = _results.asStateFlow()
    private var job: Job? = null

    fun search(query: String, apps: List<AppEntry>) {
        job?.cancel()
        val q = query.trim()
        if (q.length < 2) {
            _results.value = emptyList()
            return
        }
        job = viewModelScope.launch(Dispatchers.IO) {
            val lower = q.lowercase(Locale.getDefault())
            val output = mutableListOf<SearchResult>()

            apps.asSequence()
                .filter { it.label.lowercase(Locale.getDefault()).contains(lower) }
                .take(8)
                .forEach {
                    output += SearchResult(it.label, "Installed app", SearchType.APP, it.packageName)
                }

            queryMedia(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                arrayOf(
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.TITLE,
                    MediaStore.Audio.Media.ARTIST
                ),
                "${MediaStore.Audio.Media.TITLE} LIKE ? OR ${MediaStore.Audio.Media.ARTIST} LIKE ?",
                arrayOf("%$q%", "%$q%")
            ) { c ->
                SearchResult(
                    c.getString(1),
                    c.getString(2).orEmpty().ifBlank { "Music" },
                    SearchType.MUSIC,
                    uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, c.getLong(0))
                )
            }.take(6).also(output::addAll)

            queryMedia(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                arrayOf(MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE),
                "${MediaStore.Video.Media.TITLE} LIKE ?",
                arrayOf("%$q%")
            ) { c ->
                SearchResult(
                    c.getString(1),
                    "Video",
                    SearchType.VIDEO,
                    uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, c.getLong(0))
                )
            }.take(6).also(output::addAll)

            queryMedia(
                MediaStore.Files.getContentUri("external"),
                arrayOf(MediaStore.Files.FileColumns._ID, MediaStore.Files.FileColumns.DISPLAY_NAME, MediaStore.Files.FileColumns.MIME_TYPE),
                "${MediaStore.Files.FileColumns.DISPLAY_NAME} LIKE ?",
                arrayOf("%$q%")
            ) { c ->
                SearchResult(
                    c.getString(1),
                    c.getString(2).orEmpty().ifBlank { "Device file" },
                    SearchType.FILE,
                    uri = ContentUris.withAppendedId(MediaStore.Files.getContentUri("external"), c.getLong(0))
                )
            }.take(8).also(output::addAll)

            _results.value = output.distinctBy { "${it.type}:${it.title}:${it.packageName}:${it.uri}" }
        }
    }

    private fun queryMedia(
        uri: android.net.Uri,
        projection: Array<String>,
        selection: String,
        args: Array<String>,
        mapper: (android.database.Cursor) -> SearchResult
    ): List<SearchResult> = runCatching {
        context.contentResolver.query(uri, projection, selection, args, "${projection[1]} COLLATE NOCASE ASC")
            ?.use { c ->
                buildList {
                    while (c.moveToNext()) add(mapper(c))
                }
            }.orEmpty()
    }.getOrDefault(emptyList())
}

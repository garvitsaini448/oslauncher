package com.example.oslauncher

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.util.Locale
import java.util.concurrent.TimeUnit

class HomeActions(
    val onLaunch: (AppEntry) -> Unit,
    val onUninstall: (AppEntry) -> Unit,
    val onInfo: (AppEntry) -> Unit,
    val onRestore: () -> Unit,
    val onOpenUri: (android.net.Uri) -> Unit,
    val onWebSearch: (String, Boolean) -> Unit
)

@Composable
fun HomeScreen(
    status: StatusState,
    apps: List<AppEntry>,
    music: MusicState,
    searchResults: List<SearchResult>,
    searchQuery: String,
    actions: HomeActions,
    onSearch: (String) -> Unit,
    onMusicPlayPause: () -> Unit,
    onMusicNext: () -> Unit,
    onMusicPrevious: () -> Unit,
    onMusicSeek: (Int) -> Unit,
    onRefreshWeather: () -> Unit
) {
    var drawer by remember { mutableStateOf(false) }
    var settings by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<AppEntry?>(null) }

    if (settings) {
        SettingsScreen(
            onBack = { settings = false },
            onRestore = actions.onRestore
        )
        return
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF07101C), Color(0xFF101B2A))))
            .pointerInput(Unit) {
                var startY = 0f
                var totalDrag = 0f
                detectVerticalDragGestures(
                    onDragStart = {
                        startY = it.y
                        totalDrag = 0f
                    },
                    onVerticalDrag = { _, drag ->
                        totalDrag += drag
                        if (startY > size.height - 180.dp.toPx() && totalDrag < -80f) {
                            drawer = true
                        }
                    },
                    onDragEnd = {}
                )
            }
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 128.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                AdvancedStatusWidget(
                    status = status,
                    onSettings = { settings = true },
                    onRefreshWeather = onRefreshWeather
                )
            }
            item {
                MusicWidget(
                    state = music,
                    onPlayPause = onMusicPlayPause,
                    onNext = onMusicNext,
                    onPrevious = onMusicPrevious,
                    onSeek = onMusicSeek
                )
            }
            item {
                WindowsFolderGrid(
                    apps = apps,
                    onLaunch = actions.onLaunch,
                    onLongPress = { selected = it }
                )
            }
        }

        UniversalSearchBar(
            query = searchQuery,
            results = searchResults,
            onQuery = onSearch,
            onLaunchApp = { pkg ->
                apps.firstOrNull { it.packageName == pkg }?.let(actions.onLaunch)
            },
            onOpenUri = actions.onOpenUri,
            onWebSearch = actions.onWebSearch,
            modifier = Modifier.align(Alignment.BottomCenter)
        )

        if (drawer) {
            AppDrawer(
                apps = apps,
                onClose = { drawer = false },
                onLaunch = { drawer = false; actions.onLaunch(it) },
                onLongPress = { selected = it }
            )
        }

        selected?.let { app ->
            AppActionDialog(
                app = app,
                onDismiss = { selected = null },
                onInfo = { selected = null; actions.onInfo(app) },
                onUninstall = { selected = null; actions.onUninstall(app) }
            )
        }
    }
}

@Composable
private fun AdvancedStatusWidget(
    status: StatusState,
    onSettings: () -> Unit,
    onRefreshWeather: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = Color(0xD9101824),
        border = BorderStroke(1.dp, Color(0x33FFFFFF)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(status.time, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text(status.date, color = Color(0x99FFFFFF), fontSize = 12.sp)
                }
                Icon(
                    imageVector = if (status.wifiConnected) Icons.Default.Wifi else Icons.Default.WifiOff,
                    contentDescription = if (status.wifiConnected) "Wi-Fi connected" else "Wi-Fi disconnected",
                    tint = if (status.wifiConnected) Color(0xFF39FF66) else Color(0xFFFF3344),
                    modifier = Modifier.size(30.dp)
                )
                Spacer(Modifier.width(14.dp))
                BatteryIndicator(status.batteryPercent, status.charging)
                Spacer(Modifier.width(10.dp))
                IconButton(onClick = onSettings) {
                    Icon(Icons.Default.Settings, "Launcher settings", tint = Color.White)
                }
            }

            Spacer(Modifier.height(10.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        status.weather.temperature,
                        color = Color.White,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "${status.weather.location}${if (status.weather.description.isNotBlank()) " • ${status.weather.description}" else ""}",
                        color = Color(0xB3FFFFFF),
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onRefreshWeather) {
                    Icon(Icons.Default.Refresh, "Refresh weather", tint = Color(0xFF7DD3FC))
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                StatChip("↓ ${formatSpeed(status.downBytesPerSec)}", Color(0xFF29B6F6))
                StatChip("↑ ${formatSpeed(status.upBytesPerSec)}", Color(0xFFAB47BC))
                if (status.bluetoothOn) StatChip("BT", Color(0xFF5C6BC0))
            }
        }
    }
}

@Composable
private fun StatChip(text: String, accent: Color) {
    Surface(shape = RoundedCornerShape(50), color = accent.copy(alpha = .15f)) {
        Text(text, color = Color.White, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp))
    }
}

@Composable
private fun BatteryIndicator(percent: Int, charging: Boolean) {
    val color = when {
        charging -> Color(0xFF39FF66)
        percent <= 15 -> Color(0xFFFF3344)
        else -> Color.White
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(30.dp).height(14.dp).clip(RoundedCornerShape(4.dp)).background(Color(0x33FFFFFF))) {
            Box(
                Modifier.fillMaxHeight().fillMaxWidth((percent / 100f).coerceIn(.05f, 1f)).background(color)
            )
        }
        Spacer(Modifier.width(5.dp))
        Text("${if (charging) "⚡" else ""}$percent%", color = Color.White, fontSize = 12.sp)
    }
}

private fun formatSpeed(bytes: Long): String =
    if (bytes >= 1_048_576) String.format(Locale.US, "%.1f MB/s", bytes / 1_048_576.0)
    else String.format(Locale.US, "%d KB/s", bytes / 1024)

@Composable
private fun MusicWidget(
    state: MusicState,
    onPlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Int) -> Unit
) {
    Surface(
        shape = RoundedCornerShape(26.dp),
        color = Color(0xD91B1424),
        border = BorderStroke(1.dp, Color(0x44FFFFFF)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(68.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF30394A)),
                    contentAlignment = Alignment.Center
                ) {
                    state.track?.albumArt?.let {
                        Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    } ?: Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(34.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("MUSIC", color = Color(0xFFB8C7FF), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    Text(
                        state.track?.title ?: "No music found",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        state.track?.artist ?: "Add music to your device",
                        color = Color(0x99FFFFFF),
                        fontSize = 12.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, "Previous", tint = Color.White) }
                IconButton(onClick = onPlayPause) {
                    Icon(
                        if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        "Play or pause",
                        tint = Color.White
                    )
                }
                IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, "Next", tint = Color.White) }
            }
            Slider(
                value = state.position.toFloat().coerceIn(0f, state.duration.coerceAtLeast(1).toFloat()),
                onValueChange = { onSeek(it.toInt()) },
                valueRange = 0f..state.duration.coerceAtLeast(1).toFloat(),
                enabled = state.track != null,
                modifier = Modifier.fillMaxWidth()
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatMs(state.position), color = Color(0x99FFFFFF), fontSize = 10.sp)
                Text(formatMs(state.duration), color = Color(0x99FFFFFF), fontSize = 10.sp)
            }
        }
    }
}

private fun formatMs(ms: Int): String =
    String.format(Locale.US, "%d:%02d", TimeUnit.MILLISECONDS.toMinutes(ms), (ms / 1000) % 60)

@Composable
private fun WindowsFolderGrid(
    apps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("START", color = Color(0x99FFFFFF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        AppCategory.values().forEach { category ->
            val group = apps.filter { it.category == category }
            if (group.isNotEmpty()) {
                WindowsTileFolder(category, group, onLaunch, onLongPress)
            }
        }
    }
}

@Composable
private fun WindowsTileFolder(
    category: AppCategory,
    apps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit
) {
    val accent = when (category) {
        AppCategory.FILES -> Color(0xFF1597E5)
        AppCategory.GAMES -> Color(0xFF8B5CF6)
        AppCategory.SOCIAL -> Color(0xFF16A34A)
        AppCategory.OTHER -> Color(0xFF475569)
    }
    val preview = apps.take(4)
    Surface(
        shape = RoundedCornerShape(24.dp),
        color = accent.copy(alpha = .18f),
        border = BorderStroke(1.dp, accent.copy(alpha = .45f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.width(105.dp)) {
                Text(category.title.uppercase(), color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(category.subtitle, color = Color(0xB3FFFFFF), fontSize = 10.sp)
                Text("${apps.size} apps", color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                preview.chunked(2).take(2).forEach { rowApps ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        rowApps.forEach { app ->
                            TileApp(app, Modifier.weight(1f), onLaunch, onLongPress)
                        }
                        repeat(2 - rowApps.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun TileApp(
    app: AppEntry,
    modifier: Modifier,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit
) {
    val haptic = LocalHapticFeedback.current
    Column(
        modifier.clip(RoundedCornerShape(14.dp))
            .background(Color(0x18FFFFFF))
            .combinedClickable(
                onClick = { onLaunch(app) },
                onLongClick = {
                    haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongPress(app)
                }
            )
            .padding(6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(app.icon, app.label, Modifier.size(42.dp))
        Text(app.label, color = Color.White, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
    }
}

@Composable
private fun UniversalSearchBar(
    query: String,
    results: List<SearchResult>,
    onQuery: (String) -> Unit,
    onLaunchApp: (String) -> Unit,
    onOpenUri: (android.net.Uri) -> Unit,
    onWebSearch: (String, Boolean) -> Unit,
    modifier: Modifier
) {
    var focused by remember { mutableStateOf(false) }
    Column(modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)) {
        if (focused && query.length >= 2) {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = Color(0xF51A2330),
                border = BorderStroke(1.dp, Color(0x33FFFFFF)),
                modifier = Modifier.fillMaxWidth().heightIn(max = 260.dp)
            ) {
                LazyColumn(contentPadding = PaddingValues(8.dp)) {
                    items(results.size) { i ->
                        val r = results[i]
                        ListItem(
                            headlineContent = { Text(r.title, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            supportingContent = { Text(r.subtitle, color = Color(0x99FFFFFF), maxLines = 1) },
                            leadingContent = {
                                Icon(
                                    when (r.type) {
                                        SearchType.APP -> Icons.Default.Apps
                                        SearchType.MUSIC -> Icons.Default.MusicNote
                                        SearchType.VIDEO -> Icons.Default.VideoLibrary
                                        SearchType.FILE -> Icons.Default.InsertDriveFile
                                    },
                                    null,
                                    tint = Color.White
                                )
                            },
                            modifier = Modifier.clickable {
                                if (r.type == SearchType.APP && r.packageName != null) onLaunchApp(r.packageName)
                                else r.uri?.let(onOpenUri)
                                focused = false
                            }
                        )
                    }
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { onWebSearch(query, false) },
                                modifier = Modifier.weight(1f)
                            ) { Text("Web Search") }
                            OutlinedButton(
                                onClick = { onWebSearch(query, true) },
                                modifier = Modifier.weight(1f)
                            ) { Text("YouTube") }
                        }
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
        }

        Surface(
            shape = RoundedCornerShape(50),
            color = Color(0xF0202936),
            border = BorderStroke(1.dp, Color(0x44FFFFFF)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp)) {
                Icon(Icons.Default.Search, null, tint = Color(0xB3FFFFFF))
                BasicSearchField(
                    value = query,
                    onValueChange = { focused = true; onQuery(it) },
                    onFocus = { focused = true },
                    modifier = Modifier.weight(1f)
                )
                if (query.isNotEmpty()) {
                    IconButton(onClick = { onQuery(""); focused = false }) {
                        Icon(Icons.Default.Close, "Clear", tint = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
private fun BasicSearchField(
    value: String,
    onValueChange: (String) -> Unit,
    onFocus: () -> Unit,
    modifier: Modifier
) {
    androidx.compose.foundation.text.BasicTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier
            .padding(horizontal = 8.dp, vertical = 13.dp)
            .onFocusChanged { if (it.isFocused) onFocus() },
        singleLine = true,
        textStyle = LocalTextStyle.current.copy(color = Color.White, fontSize = 14.sp),
        decorationBox = { inner ->
            if (value.isEmpty()) Text("Search apps, music, videos & files…", color = Color(0x88FFFFFF), fontSize = 14.sp)
            inner()
        }
    )
}

@Composable
private fun AppDrawer(
    apps: List<AppEntry>,
    onClose: () -> Unit,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit
) {
    Surface(
        color = Color(0xF607101C),
        modifier = Modifier
            .fillMaxSize()
            .clickable(onClick = onClose)
            .pointerInput(Unit) {
                var totalDrag = 0f
                detectVerticalDragGestures(
                    onDragStart = { totalDrag = 0f },
                    onVerticalDrag = { _, drag ->
                        totalDrag += drag
                        if (totalDrag > 90f) onClose()
                    }
                )
            }
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 14.dp)) {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("APP DRAWER", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Swipe down to close", color = Color(0x99FFFFFF), fontSize = 11.sp)
                }
                IconButton(onClick = onClose) { Icon(Icons.Default.Close, "Close", tint = Color.White) }
            }
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                contentPadding = PaddingValues(bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(apps, key = { it.packageName }) { app ->
                    TileApp(app, Modifier.fillMaxWidth(), onLaunch, onLongPress)
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(onBack: () -> Unit, onRestore: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Color(0xFF09111D)).statusBarsPadding().padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back", tint = Color.White) }
            Text("Launcher Settings", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(18.dp))
        Surface(shape = RoundedCornerShape(24.dp), color = Color(0xFF162130)) {
            Column(Modifier.padding(18.dp)) {
                Text("System Launcher", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(6.dp))
                Text(
                    "Switch back to Samsung One UI Home from Android's default Home app settings.",
                    color = Color(0xB3FFFFFF), fontSize = 13.sp
                )
                Spacer(Modifier.height(14.dp))
                Button(onClick = onRestore, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Home, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Restore One UI Home")
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("OS Launcher 2.0", color = Color(0x66FFFFFF), fontSize = 12.sp)
    }
}

@Composable
private fun AppActionDialog(
    app: AppEntry,
    onDismiss: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(26.dp), color = Color(0xFF1B2634)) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(app.icon, app.label, Modifier.size(64.dp))
                Spacer(Modifier.height(8.dp))
                Text(app.label, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(app.packageName, color = Color(0x99FFFFFF), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(16.dp))
                Button(onClick = onInfo, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Info, null); Spacer(Modifier.width(8.dp)); Text("App Info")
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = onUninstall,
                    enabled = app.canUninstall,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Delete, null); Spacer(Modifier.width(8.dp)); Text("Uninstall")
                }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        }
    }
}

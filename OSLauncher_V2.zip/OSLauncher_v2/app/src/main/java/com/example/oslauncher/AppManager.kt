package com.example.oslauncher

import android.app.Application
import android.content.*
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.Locale

enum class AppCategory(val title: String, val subtitle: String) {
    FILES("Files", "Documents & storage"),
    GAMES("Games", "Play & entertainment"),
    SOCIAL("Social", "People & communication"),
    OTHER("Apps", "Everything else")
}

data class AppEntry(
    val label: String,
    val packageName: String,
    val icon: ImageBitmap,
    val category: AppCategory,
    val isSystem: Boolean
) {
    val canUninstall: Boolean get() = !isSystem
}

class AppManager(private val context: Context) {
    suspend fun loadApps(): List<AppEntry> = withContext(Dispatchers.Default) {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = if (Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION") pm.queryIntentActivities(intent, 0)
        }

        resolved.asSequence()
            .filter { it.activityInfo.packageName != context.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { ri ->
                val ai = ri.activityInfo.applicationInfo
                val label = ri.loadLabel(pm).toString()
                val pkg = ri.activityInfo.packageName
                AppEntry(
                    label = label,
                    packageName = pkg,
                    icon = ri.loadIcon(pm).toBitmap(112, 112).asImageBitmap(),
                    category = categorize(ai, pkg, label),
                    isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                        (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                )
            }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
            .toList()
    }

    private fun categorize(ai: ApplicationInfo, pkg: String, label: String): AppCategory {
        val p = pkg.lowercase(Locale.ROOT)
        val l = label.lowercase(Locale.getDefault())
        return when {
            isFileApp(p, l) -> AppCategory.FILES
            isGame(ai, p) -> AppCategory.GAMES
            isSocial(p) -> AppCategory.SOCIAL
            else -> AppCategory.OTHER
        }
    }

    private fun isFileApp(p: String, l: String) =
        p in FILE_PACKAGES || FILE_KEYWORDS.any { p.contains(it) } ||
            l.contains("file manager") || l.contains("my files") || l == "files" ||
            l.contains("file explorer") || l.contains("storage")

    @Suppress("DEPRECATION")
    private fun isGame(ai: ApplicationInfo, p: String): Boolean =
        (Build.VERSION.SDK_INT >= 26 && ai.category == ApplicationInfo.CATEGORY_GAME) ||
            (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0 ||
            GAME_PREFIXES.any { p.startsWith(it) } || p.contains(".game") || p.contains("games")

    private fun isSocial(p: String) =
        p in SOCIAL_PACKAGES || p.startsWith("com.google.") || p.startsWith("com.facebook.")

    private companion object {
        val FILE_PACKAGES = setOf(
            "com.sec.android.app.myfiles", "com.google.android.apps.nbu.files",
            "com.android.documentsui", "com.google.android.documentsui",
            "com.google.android.apps.docs", "com.estrongs.android.pop",
            "com.lonelycatgames.xplore", "com.alphainventor.filemanager",
            "com.cxinventor.file.explorer", "com.ghisler.android.totalcommander",
            "com.dropbox.android", "com.microsoft.skydrive", "com.mi.android.globalfileexplorer"
        )
        val FILE_KEYWORDS = listOf("filemanager", "fileexplorer", "file.explorer", "myfiles", "documentsui")
        val GAME_PREFIXES = listOf(
            "com.supercell", "com.activision", "com.tencent.ig", "com.garena", "com.mojang",
            "com.miniclip", "com.king.", "com.roblox", "com.epicgames", "com.ea.", "com.gameloft",
            "com.kiloo", "com.halfbrick", "com.innersloth", "com.dts.freefire", "com.pubg",
            "com.mobile.legends", "com.moonton", "com.nianticlabs", "com.rovio", "com.zynga"
        )
        val SOCIAL_PACKAGES = setOf(
            "com.whatsapp", "com.whatsapp.w4b", "com.instagram.android", "com.twitter.android",
            "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "org.telegram.messenger",
            "com.snapchat.android", "com.reddit.frontpage", "com.linkedin.android",
            "com.discord", "com.pinterest", "com.android.chrome", "org.thoughtcrime.securesms",
            "com.viber.voip", "com.tumblr"
        )
    }
}

class AppsViewModel(application: Application) : AndroidViewModel(application) {
    private val manager = AppManager(application)
    private val _apps = MutableStateFlow<List<AppEntry>>(emptyList())
    val apps = _apps.asStateFlow()
    private var job: Job? = null

    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) { refresh() }
    }

    init {
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(application, packageReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        refresh()
    }

    fun refresh() {
        job?.cancel()
        job = viewModelScope.launch { _apps.value = manager.loadApps() }
    }

    override fun onCleared() {
        runCatching { getApplication<Application>().unregisterReceiver(packageReceiver) }
        super.onCleared()
    }
}

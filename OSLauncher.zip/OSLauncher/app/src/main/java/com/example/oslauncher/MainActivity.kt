package com.example.oslauncher

import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color as AColor
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.lifecycle.compose.collectAsStateWithLifecycle

class MainActivity : ComponentActivity() {

    private val statusVm: StatusViewModel by viewModels()
    private val appsVm: AppsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Transparent bars; we keep the REAL system status bar visible so
        // Samsung's pull-down notification / quick settings shade works untouched.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(AColor.TRANSPARENT)
        )

        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                val status by statusVm.state.collectAsStateWithLifecycle()
                val apps by appsVm.apps.collectAsStateWithLifecycle()

                // A launcher must never "go back" out of itself.
                BackHandler(enabled = true) { }

                val actions = remember {
                    HomeActions(
                        onLaunch = ::launchApp,
                        onUninstall = ::uninstallApp,
                        onInfo = ::openAppInfo,
                        onRestore = ::restoreDefaultLauncher
                    )
                }
                HomeScreen(status = status, apps = apps, actions = actions)
            }
        }
    }

    private fun launchApp(app: AppEntry) {
        val intent = packageManager.getLaunchIntentForPackage(app.packageName)
        if (intent == null) {
            toast("Cannot open ${app.label}")
            return
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        safeStart(intent)
    }

    /** Triggers the system uninstall confirmation dialog. */
    private fun uninstallApp(app: AppEntry) {
        if (!app.canUninstall) {
            toast("${app.label} is a system app and can't be uninstalled")
            return
        }
        safeStart(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}")))
    }

    private fun openAppInfo(app: AppEntry) {
        safeStart(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))
        )
    }

    /** One tap -> Settings > Default apps > Home app, to switch back to One UI Home. */
    private fun restoreDefaultLauncher() {
        try {
            startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
        } catch (e: ActivityNotFoundException) {
            safeStart(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun safeStart(intent: Intent) {
        try {
            startActivity(intent)
        } catch (e: Exception) {
            toast("Action not available on this device")
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}

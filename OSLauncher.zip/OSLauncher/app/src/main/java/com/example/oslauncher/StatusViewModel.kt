package com.example.oslauncher

import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.TrafficStats
import android.os.BatteryManager
import android.os.SystemClock
import android.text.format.DateFormat
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

data class StatusState(
    val time: String = "--:--",
    val date: String = "",
    val downBytesPerSec: Long = 0,
    val upBytesPerSec: Long = 0,
    val wifiConnected: Boolean = false,
    val bluetoothOn: Boolean = false,
    val batteryPercent: Int = 0,
    val charging: Boolean = false
)

class StatusViewModel(application: Application) : AndroidViewModel(application) {

    private val ctx: Context = application.applicationContext
    private val _state = MutableStateFlow(StatusState())
    val state: StateFlow<StatusState> = _state.asStateFlow()

    private val connectivity = ctx.getSystemService(ConnectivityManager::class.java)

    // ---- System receivers -------------------------------------------------

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = applyBattery(intent)
    }

    private val bluetoothReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            val s = intent.getIntExtra(BluetoothAdapter.EXTRA_STATE, BluetoothAdapter.ERROR)
            _state.update { it.copy(bluetoothOn = s == BluetoothAdapter.STATE_ON) }
        }
    }

    private val wifiCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            _state.update { it.copy(wifiConnected = true) }
        }
        override fun onLost(network: Network) {
            _state.update { it.copy(wifiConnected = false) }
        }
    }

    init {
        // Battery (sticky -> immediate first value)
        ContextCompat.registerReceiver(
            ctx, batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )?.let { applyBattery(it) }

        // Bluetooth
        ContextCompat.registerReceiver(
            ctx, bluetoothReceiver, IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED),
            ContextCompat.RECEIVER_NOT_EXPORTED
        )
        val btOn = try {
            ctx.getSystemService(BluetoothManager::class.java)?.adapter?.isEnabled == true
        } catch (e: SecurityException) { false }

        // Wi-Fi
        val wifiNow = connectivity?.let { cm ->
            cm.getNetworkCapabilities(cm.activeNetwork)
                ?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        } ?: false
        connectivity?.registerNetworkCallback(
            NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build(),
            wifiCallback
        )
        _state.update { it.copy(bluetoothOn = btOn, wifiConnected = wifiNow) }

        startTickLoop()
    }

    private fun applyBattery(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else 0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        _state.update { it.copy(batteryPercent = pct, charging = charging) }
    }

    /** Once per second: refresh the clock and compute live network throughput. */
    private fun startTickLoop() = viewModelScope.launch {
        var lastRx = TrafficStats.getTotalRxBytes()
        var lastTx = TrafficStats.getTotalTxBytes()
        var lastT = SystemClock.elapsedRealtime()

        while (isActive) {
            val now = LocalDateTime.now()
            val timePattern = if (DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm a"
            val timeStr = now.format(DateTimeFormatter.ofPattern(timePattern, Locale.getDefault()))
            val dateStr = now.format(DateTimeFormatter.ofPattern("EEEE, d MMM", Locale.getDefault()))

            val rx = TrafficStats.getTotalRxBytes()
            val tx = TrafficStats.getTotalTxBytes()
            val t = SystemClock.elapsedRealtime()
            val dt = (t - lastT).coerceAtLeast(1)
            val supported = rx != TrafficStats.UNSUPPORTED.toLong() && tx != TrafficStats.UNSUPPORTED.toLong()
            val down = if (supported) ((rx - lastRx) * 1000 / dt).coerceAtLeast(0) else 0
            val up = if (supported) ((tx - lastTx) * 1000 / dt).coerceAtLeast(0) else 0
            lastRx = rx; lastTx = tx; lastT = t

            _state.update {
                it.copy(time = timeStr, date = dateStr, downBytesPerSec = down, upBytesPerSec = up)
            }
            delay(1000)
        }
    }

    override fun onCleared() {
        runCatching { ctx.unregisterReceiver(batteryReceiver) }
        runCatching { ctx.unregisterReceiver(bluetoothReceiver) }
        runCatching { connectivity?.unregisterNetworkCallback(wifiCallback) }
        super.onCleared()
    }
}

package com.example.oslauncher

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import java.util.Locale

class HomeActions(
    val onLaunch: (AppEntry) -> Unit,
    val onUninstall: (AppEntry) -> Unit,
    val onInfo: (AppEntry) -> Unit,
    val onRestore: () -> Unit
)

private val AppCategory.tint: Color
    get() = when (this) {
        AppCategory.FILES -> Color(0xFF29B6F6)
        AppCategory.GAMES -> Color(0xFFAB47BC)
        AppCategory.SOCIAL -> Color(0xFF66BB6A)
        AppCategory.OTHER -> Color(0xFF90A4AE)
    }

private val AppCategory.emoji: String
    get() = when (this) {
        AppCategory.FILES -> "📁"
        AppCategory.GAMES -> "🎮"
        AppCategory.SOCIAL -> "💬"
        AppCategory.OTHER -> "📱"
    }

private const val COLUMNS = 4
private const val COLLAPSED_LIMIT = 8

@Composable
fun HomeScreen(status: StatusState, apps: List<AppEntry>, actions: HomeActions) {
    var selected by remember { mutableStateOf<AppEntry?>(null) }
    val grouped = remember(apps) { apps.groupBy { it.category } }

    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xB30B1220), Color(0xE6101A2B))))
    ) {
        // statusBarsPadding keeps the real system status bar free -> pull-down shade still works.
        LazyColumn(
            modifier = Modifier.fillMaxSize().statusBarsPadding(),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 110.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item { DynamicStatusBar(status) }
            AppCategory.values().forEach { cat ->
                val list = grouped[cat].orEmpty()
                if (list.isNotEmpty()) {
                    item(key = cat.name) {
                        CategoryCard(cat, list, actions.onLaunch) { selected = it }
                    }
                }
            }
        }

        // Emergency safe switcher
        ExtendedFloatingActionButton(
            onClick = actions.onRestore,
            containerColor = Color(0xFFE53935),
            contentColor = Color.White,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .navigationBarsPadding()
                .padding(16.dp)
        ) {
            Text("↩  Restore One UI", fontWeight = FontWeight.SemiBold)
        }
    }

    selected?.let { app ->
        AppActionDialog(
            app = app,
            onDismiss = { selected = null },
            onInfo = { selected = null; actions.onInfo(app) },
            onUninstall = { selected = null; actions.onUninstall(app) }
        )
    }
}

// ---------------------------------------------------------------- Status bar

@Composable
fun DynamicStatusBar(s: StatusState) {
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = Color(0xCC000000),
        border = BorderStroke(1.dp, Color(0x33FFFFFF)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(horizontal = 18.dp, vertical = 14.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(s.time, color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text(s.date, color = Color(0xB3FFFFFF), fontSize = 12.sp)
                }
                BatteryIndicator(s.batteryPercent, s.charging)
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatChip(
                    "↓ ${formatSpeed(s.downBytesPerSec)}   ↑ ${formatSpeed(s.upBytesPerSec)}",
                    Color(0xFF29B6F6), true
                )
                StatChip(if (s.wifiConnected) "Wi-Fi Connected" else "Wi-Fi Off", Color(0xFF66BB6A), s.wifiConnected)
                StatChip(if (s.bluetoothOn) "Bluetooth On" else "Bluetooth Off", Color(0xFF5C6BC0), s.bluetoothOn)
            }
        }
    }
}

@Composable
private fun StatChip(text: String, accent: Color, active: Boolean) {
    val c = if (active) accent else Color(0xFF78909C)
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(c.copy(alpha = 0.18f))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(c))
        Spacer(Modifier.width(7.dp))
        Text(text, color = Color.White, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
private fun BatteryIndicator(percent: Int, charging: Boolean) {
    val color = when {
        charging -> Color(0xFF66BB6A)
        percent <= 15 -> Color(0xFFE53935)
        else -> Color.White
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .width(34.dp).height(15.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0x33FFFFFF))
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth((percent / 100f).coerceIn(0.05f, 1f))
                    .background(color)
            )
        }
        Spacer(Modifier.width(6.dp))
        Text(
            (if (charging) "⚡" else "") + "$percent%",
            color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium
        )
    }
}

private fun formatSpeed(bytesPerSec: Long): String =
    if (bytesPerSec >= 1_048_576) String.format(Locale.US, "%.1f MB/s", bytesPerSec / 1_048_576.0)
    else String.format(Locale.US, "%d KB/s", bytesPerSec / 1024)

// ------------------------------------------------------------ Category cards

@Composable
private fun CategoryCard(
    category: AppCategory,
    apps: List<AppEntry>,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit
) {
    var expanded by remember(category) { mutableStateOf(false) }
    val visible = if (expanded || apps.size <= COLLAPSED_LIMIT) apps else apps.take(COLLAPSED_LIMIT)
    val tint = category.tint

    Surface(
        shape = RoundedCornerShape(24.dp),
        color = tint.copy(alpha = 0.16f),
        border = BorderStroke(1.dp, tint.copy(alpha = 0.40f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${category.emoji}  ${category.title}",
                    color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                Text("${apps.size}", color = Color(0xB3FFFFFF), fontSize = 13.sp)
            }
            Spacer(Modifier.height(10.dp))

            visible.chunked(COLUMNS).forEach { rowApps ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    rowApps.forEach { app ->
                        AppCell(app, Modifier.weight(1f), onLaunch, onLongPress)
                    }
                    repeat(COLUMNS - rowApps.size) { Spacer(Modifier.weight(1f)) }
                }
            }

            if (apps.size > COLLAPSED_LIMIT) {
                TextButton(onClick = { expanded = !expanded }, modifier = Modifier.align(Alignment.End)) {
                    Text(if (expanded) "Show less" else "Show all (${apps.size})", color = tint)
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppCell(
    app: AppEntry,
    modifier: Modifier,
    onLaunch: (AppEntry) -> Unit,
    onLongPress: (AppEntry) -> Unit
) {
    val haptics = LocalHapticFeedback.current
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .combinedClickable(
                onClick = { onLaunch(app) },
                onLongClick = {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    onLongPress(app)
                }
            )
            .padding(vertical = 6.dp, horizontal = 2.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(bitmap = app.icon, contentDescription = app.label, modifier = Modifier.size(50.dp))
        Spacer(Modifier.height(4.dp))
        Text(
            app.label, color = Color.White, fontSize = 11.sp, maxLines = 2,
            overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, lineHeight = 13.sp
        )
    }
}

// ------------------------------------------------------------- Long-press UI

@Composable
private fun AppActionDialog(
    app: AppEntry,
    onDismiss: () -> Unit,
    onInfo: () -> Unit,
    onUninstall: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(shape = RoundedCornerShape(26.dp), color = Color(0xFF1B232E)) {
            Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Image(bitmap = app.icon, contentDescription = null, modifier = Modifier.size(64.dp))
                Spacer(Modifier.height(8.dp))
                Text(app.label, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(app.packageName, color = Color(0x99FFFFFF), fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.height(16.dp))

                ActionRow("ℹ️  App Info", Color.White, true, onInfo)
                Spacer(Modifier.height(8.dp))
                ActionRow(
                    if (app.canUninstall) "🗑️  Uninstall / Delete App" else "🗑️  System app (can't uninstall)",
                    if (app.canUninstall) Color(0xFFFF6B6B) else Color(0xFF78909C),
                    app.canUninstall, onUninstall
                )
                Spacer(Modifier.height(6.dp))
                TextButton(onClick = onDismiss) { Text("Cancel", color = MaterialTheme.colorScheme.primary) }
            }
        }
    }
}

@Composable
private fun ActionRow(text: String, color: Color, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x1FFFFFFF))
            .combinedClickableSafe(enabled, onClick)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Text(text, color = color, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

@OptIn(ExperimentalFoundationApi::class)
private fun Modifier.combinedClickableSafe(enabled: Boolean, onClick: () -> Unit): Modifier =
    this.combinedClickable(enabled = enabled, onClick = onClick)
